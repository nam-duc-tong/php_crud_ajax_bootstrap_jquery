<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Bootstrap</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
   <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <script
    src="https://code.jquery.com/jquery-3.2.1.min.js"
    integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
    crossorigin="anonymous"></script>
</head>
<body>
  <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="completeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form>
        <div class="mb-3">
          <label for="completename" class="form-label">Name</label>
        </div>
          <input type="text" class="form-control" id="completename"  placeholder="Input your Name ">          
        <div class="mb-3">
          <label for="completeemail" class="form-label">Email</label>
          <input type="email" class="form-control" id="completeemail"  placeholder="Input your Email ">          
        </div>
        <div class="mb-3">
          <label for="completemobile" class="form-label">Mobile</label>
          <input type="number" class="form-control" id="completemobile"  placeholder="Input your Mobile ">          
        </div>
        <div class="mb-3">
          <label for="completeplace" class="form-label">Place</label>
          <input type="text" class="form-control" id="completeplace"  placeholder="Input your Place ">          
         </div>

      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" onclick="adduser()">Submit</button>
        <button type="button" class="btn btn-danger close_window" onclick="closeDialog()">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- update modal -->
<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" >Update Detail</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form>
        <div class="mb-3">
          <label for="updatename" class="form-label">Name</label>
        </div>
          <input type="text" class="form-control" id="updatename"  placeholder="Input your Name ">          
        <div class="mb-3">
          <label for="updateemail" class="form-label">Email</label>
          <input type="email" class="form-control" id="updateemail"  placeholder="Input your Email ">          
        </div>
        <div class="mb-3">
          <label for="updatemobile" class="form-label">Mobile</label>
          <input type="number" class="form-control" id="updatemobile"  placeholder="Input your Mobile ">          
        </div>
        <div class="mb-3">
          <label for="updateplace" class="form-label">Place</label>
          <input type="text" class="form-control" id="updateplace"  placeholder="Input your Place ">          
         </div>

      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" onclick="updateDetails()">Submit</button>
        <button type="button" class="btn btn-danger close_window" onclick="closeDialog()">Close</button>
        <input type="hidden" id="hiddendata">
      </div>
    </div>
  </div>
</div>
    <div class="container my-3">
      <h1 class="text-center">PHP CRUD using Bootstrap Modal || Complete Project || AJAX || JQUERY</h1>
      <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#completeModal">
          Add New User
      </button>
      <div id="displayDataTable"></div>
      
    </div>

  <script>
    $(document).ready(function(){
        displayData();
    });
    //an form va reload page
    var element = document.getElementById("completeModal");
    function closeDialog() {
      element.style.visibility = "hidden";
      window.location.reload();
    }

      //display function
  function displayData() {
    var displayData = "true";
    $.ajax({
        url:"display.php",
        type:'post',
        data:{
          displaySend:displayData
        },
        success:function(data,status)
        {
            $('#displayDataTable').html(data);
        }
    });
}

  function adduser(){
      var nameAdd = $('#completename').val();
      var emailAdd = $('#completeemail').val();
      var mobileAdd = $('#completemobile').val();
      var placeAdd = $('#completeplace').val();
      
      $.ajax({
          url:"insert.php",
          type:'post',
          data:{
            nameSend:nameAdd,
            emailSend:emailAdd,
            mobileSend:mobileAdd,
            placeSend:placeAdd,
          },
          success:function(data,status)
          {
            //function to display data
            // console.log(status);
            $('#completeModal').modal('hide');
            window.location.reload();
            displayData();
          }
      });
  }
  // delete record
  function DeleteUser(deleteid)
  {
      $.ajax({
        url:"delete.php",
        type:'post',
        data:{
            deletesend:deleteid
        },
        success:function(data,status){
          displayData();
          // console.log(status);
        }
      });
  }
  function GetDetails(updateid)
  {
    $('#hiddendata').val(updateid);
    $.post("update.php",{updateid:updateid},function(data,status){
        var userid = JSON.parse(data);
        $('#updatename').val(userid.name);
        $('#updateemail').val(userid.email);
        $('#updatemobile').val(userid.mobile);
        $('#updateplace').val(userid.place);
      });
    $('#updateModal').modal('show');
  }
  // onclick update update event function
  function updateDetails()
  {
    var updatename = $('#updatename').val();
    var updateemail = $('#updateemail').val();
    var updatemobile = $('#updatemobile').val();
    var updateplace = $('#updateplace').val();
    var hiddendata = $('#hiddendata').val();

    $.post("update.php",{
      updatename:updatename,
      updateemail:updateemail,
      updatemobile:updatemobile,
      updateplace:updateplace,
      hiddendata:hiddendata,
    },function(data,status){
      $('#updateModal').modal('hide');
      displayData();
    });
  }
  </script>
  </body>
</html>