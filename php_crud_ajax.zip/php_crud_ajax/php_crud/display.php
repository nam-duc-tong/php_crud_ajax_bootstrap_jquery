<style>
    .btn-dark{
        margin-right:5px;
    }
</style>
<?php
    include 'connect.php';
    if(isset($_POST['displaySend']))
    {
        $table = '<table class="table">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col">STT</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Place</th>
                        <th scope="col">Operations</th>
                    </tr>
                    </thead>';
                $i = 1;
                $sql = "Select * From `crud_bootstrap`";
                $result = mysqli_query($connect,$sql);
                while($row = mysqli_fetch_assoc($result))
              {
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $mobile = $row['mobile'];
                    $place = $row['place'];
                    $table .='
                     <tr>
                        <td scope="row">'.$i++.'</td>
                        <td>'.$name.'</td>
                        <td>'.$email.'</td>
                        <td>'.$mobile.'</td>
                        <td>'.$place.'</td>
                        <td><button class="btn btn-dark" onclick="GetDetails('.$id.')">Update</button><button class="btn btn-danger" onclick="DeleteUser('.$id.')">Delete</button></td>   
                    </tr>    
                    ';
                }
                $table.='</table>';
                echo $table;
    }
?>

