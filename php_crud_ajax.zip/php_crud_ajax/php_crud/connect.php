<?php
    $connect = new mysqli('localhost','root','','php_crud');
    if(!$connect)
    {
        die(myqli_error($con));
    }

?>