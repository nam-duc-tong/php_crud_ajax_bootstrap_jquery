<?php
    include 'connect.php';
    if(isset($_POST['deletesend']))
    {
        $unique = $_POST['deletesend'];
        $sql = "Delete from `crud_bootstrap` where id = $unique";
        $result = mysqli_query($connect, $sql);
        // echo $unique;
        // echo "Da click";
    }

?>